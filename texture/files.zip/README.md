N64 Fire
========

Animated fire sprites that replicate those that appear in Ocarina of Time atop torches and as barriers.

In the provided ZIP file, in the folder "Frames", there are animation frame sets for six colors: natural (orange), red, green, blue, purple and white. Each frame set loops at 30 FPS, which is close to the frame rate of Ocarina of Time.

The natural and red colors look similar, but the difference is that the natural color is slightly more orange.

There are three categories of frame sets: flat, faded and round. Flat frames just represent a colored fire texture travelling upwards and are tileable in both vertically and horizontally. Faded frames use alpha to represent the texture fading out upwards as if the fire were cooling down and are tileable horizontally but not vertically. Round frames represent a single flame, perhaps atop a torch, and are not tileable.

The fire sprites are deliberately low-resolution and made to look archaic to replicate the style of the Nintendo 64.

In the folder "Textures" are two files: a "Gradient" image which is a tileable map of the temperature of a fire sprite and a "Round alpha" image which is used to constrain the size of the round form of a sprite.

Also provided is a Blender file in the folder "Custom" for making sprites with custom colors apart from those already pre-rendered. In this file is a fire sprite appearing in the three aforementioned forms: flat, faded and round. To edit the color of the sprite, select any of the objects representing the forms, then go the material view of the object, then open the "Color" group. There is a "Texture to color" node which is a gradient map of the "Gradient" image to a color temperature range. Edit the stops in this gradient map as desired.

When you are happy with the color, choose a camera for a form to render: either flat, faded or round. Render an animation. Blender will then render your chosen color and form in 30 animation frames (in your temporary output folder).

Enjoy!


Version
-------

2024-12-23


Software used
-------------

Aseprite version 1.3.9.1 to draw the "Gradient" and "Round alpha" images and Blender version 4.2 to render the sprites.

A drawing tablet was used to produce soft brush work in the images.


License
-------

CC0 (public domain). Credit as n64guy would be nice but is not required.